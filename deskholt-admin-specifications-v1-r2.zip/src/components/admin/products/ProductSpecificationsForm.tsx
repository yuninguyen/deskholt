// src/components/admin/products/ProductSpecificationsForm.tsx
"use client";

// R2-fix: repo Deskholt hiện dùng Next.js 14 + React 18 (không phải React 19),
// nên KHÔNG dùng useActionState (API chỉ có ở React 19). Thay bằng
// useFormState (react-dom) — cùng chức năng nhưng không trả về `pending`,
// nên trạng thái pending lấy riêng qua useFormStatus() ở component con
// SubmitButton bên dưới (bắt buộc phải là component con vì useFormStatus()
// chỉ đọc được trạng thái của <form> cha gần nhất khi gọi từ bên trong nó).
import { useFormState, useFormStatus } from "react-dom";
import type {
  AttributeDataType,
  AttributeScope,
  Confidence,
  SourceType,
} from "@prisma/client";

import {
  saveProductSpecifications,
  type SaveSpecificationsState,
} from "@/app/(admin)/admin/products/[id]/specifications/actions";

type AttributeDefinitionVM = {
  id: number;
  key: string;
  label: string;
  scope: AttributeScope;
  dataType: AttributeDataType;
  unit: string | null;
  allowedValues: string[];
};

type CategoryAttributeVM = {
  isRequired: boolean;
  displayOrder: number;
  definition: AttributeDefinitionVM;
};

type VariantVM = {
  id: number;
  sku: string | null;
  size: string | null;
  color: string | null;
  material: string | null;
  width: string | null;
  depth: string | null;
};

type ProductAttributeVM = {
  id: number;
  attributeDefinitionId: number;
  variantId: number | null;
  valueString: string | null;
  valueNumber: string | null;
  valueBoolean: boolean | null;
  sourceUrl: string | null;
  sourceType: SourceType | null;
  confidence: Confidence;
  verifiedAt: string | null;
};

type Props = {
  product: {
    id: number;
    name: string;
    categoryName: string;
  };
  attributes: CategoryAttributeVM[];
  variants: VariantVM[];
  values: ProductAttributeVM[];
};

const initialState: SaveSpecificationsState = {
  ok: false,
  errors: [],
};

function fieldName(
  attributeDefinitionId: number,
  variantId: number | null,
  field: "value" | "sourceUrl" | "sourceType" | "confidence"
) {
  return `attr.${attributeDefinitionId}.${variantId ?? 0}.${field}`;
}

function valueKey(attributeDefinitionId: number, variantId: number | null) {
  return `${attributeDefinitionId}:${variantId ?? 0}`;
}

function variantLabel(variant: VariantVM) {
  const parts = [
    variant.size,
    variant.material,
    variant.color,
    variant.sku ? `SKU ${variant.sku}` : null,
  ].filter(Boolean);

  return parts.length ? parts.join(" · ") : `Variant #${variant.id}`;
}

function displayValue(
  definition: AttributeDefinitionVM,
  current?: ProductAttributeVM
): string {
  if (!current) return "";

  if (definition.dataType === "BOOLEAN") {
    if (current.valueBoolean === null) return "";
    return current.valueBoolean ? "true" : "false";
  }

  if (
    definition.dataType === "DECIMAL" ||
    definition.dataType === "INTEGER"
  ) {
    return current.valueNumber ?? "";
  }

  return current.valueString ?? "";
}

function ValueInput({
  definition,
  current,
  name,
}: {
  definition: AttributeDefinitionVM;
  current?: ProductAttributeVM;
  name: string;
}) {
  const value = displayValue(definition, current);

  if (definition.dataType === "BOOLEAN") {
    return (
      <select
        name={name}
        defaultValue={value}
        className="w-full rounded-md border px-3 py-2 text-sm"
      >
        <option value="">— Chưa nhập —</option>
        <option value="true">Yes</option>
        <option value="false">No</option>
      </select>
    );
  }

  if (definition.dataType === "ENUM") {
    return (
      <select
        name={name}
        defaultValue={value}
        className="w-full rounded-md border px-3 py-2 text-sm"
      >
        <option value="">— Chưa nhập —</option>
        {definition.allowedValues.map((allowed) => (
          <option key={allowed} value={allowed}>
            {allowed}
          </option>
        ))}
      </select>
    );
  }

  if (
    definition.dataType === "DECIMAL" ||
    definition.dataType === "INTEGER"
  ) {
    return (
      <input
        name={name}
        type="number"
        step={definition.dataType === "INTEGER" ? "1" : "any"}
        defaultValue={value}
        className="w-full rounded-md border px-3 py-2 text-sm font-mono"
        placeholder={definition.unit ?? undefined}
      />
    );
  }

  return (
    <input
      name={name}
      type="text"
      defaultValue={value}
      className="w-full rounded-md border px-3 py-2 text-sm"
    />
  );
}

function AttributeRow({
  attribute,
  variant,
  current,
}: {
  attribute: CategoryAttributeVM;
  variant: VariantVM | null;
  current?: ProductAttributeVM;
}) {
  const d = attribute.definition;
  const variantId = variant?.id ?? null;

  return (
    <div className="grid grid-cols-12 gap-3 border-b py-4 last:border-b-0">
      <div className="col-span-12 lg:col-span-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-medium">{d.label}</span>
          {attribute.isRequired ? (
            <span className="rounded bg-red-50 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-red-700">
              Required
            </span>
          ) : null}
          <span className="rounded bg-neutral-100 px-1.5 py-0.5 font-mono text-[10px] text-neutral-600">
            {d.scope}
          </span>
        </div>

        <p className="mt-1 font-mono text-xs text-neutral-500">{d.key}</p>

        {variant ? (
          <p className="mt-1 text-xs text-blue-700">{variantLabel(variant)}</p>
        ) : (
          <p className="mt-1 text-xs text-neutral-500">Product-level</p>
        )}
      </div>

      <div className="col-span-12 lg:col-span-2">
        <label className="mb-1 block text-xs text-neutral-500">
          Value {d.unit ? `(${d.unit})` : ""}
        </label>
        <ValueInput
          definition={d}
          current={current}
          name={fieldName(d.id, variantId, "value")}
        />
      </div>

      <div className="col-span-12 lg:col-span-3">
        <label className="mb-1 block text-xs text-neutral-500">
          Source URL
        </label>
        <input
          type="url"
          name={fieldName(d.id, variantId, "sourceUrl")}
          defaultValue={current?.sourceUrl ?? ""}
          placeholder="https://..."
          className="w-full rounded-md border px-3 py-2 text-sm"
        />
      </div>

      <div className="col-span-6 lg:col-span-2">
        <label className="mb-1 block text-xs text-neutral-500">
          Source Type
        </label>
        <select
          name={fieldName(d.id, variantId, "sourceType")}
          defaultValue={current?.sourceType ?? ""}
          className="w-full rounded-md border px-3 py-2 text-sm"
        >
          <option value="">—</option>
          <option value="MANUFACTURER">Manufacturer</option>
          <option value="MANUAL">Manual</option>
          <option value="RETAILER">Retailer</option>
          <option value="CERTIFICATION">Certification</option>
          <option value="OTHER">Other</option>
        </select>
      </div>

      <div className="col-span-6 lg:col-span-2">
        <label className="mb-1 block text-xs text-neutral-500">
          Confidence
        </label>
        <select
          name={fieldName(d.id, variantId, "confidence")}
          defaultValue={current?.confidence ?? "UNVERIFIED"}
          className="w-full rounded-md border px-3 py-2 text-sm"
        >
          <option value="UNVERIFIED">Unverified</option>
          <option value="LIKELY">Likely</option>
          <option value="VERIFIED">Verified</option>
        </select>
      </div>
    </div>
  );
}

export function ProductSpecificationsForm({
  product,
  attributes,
  variants,
  values,
}: Props) {
  const [state, formAction] = useFormState(
    saveProductSpecifications,
    initialState
  );

  const existing = new Map(
    values.map((value) => [
      valueKey(value.attributeDefinitionId, value.variantId),
      value,
    ])
  );

  const productAttrs = attributes.filter(
    (a) => a.definition.scope === "PRODUCT"
  );
  const variantAttrs = attributes.filter(
    (a) => a.definition.scope === "VARIANT"
  );
  const derivedAttrs = attributes.filter(
    (a) => a.definition.scope === "DERIVED"
  );

  const requiredTargets =
    productAttrs.filter((a) => a.isRequired).length +
    variantAttrs.filter((a) => a.isRequired).length * variants.length;

  const filledRequiredTargets =
    productAttrs.filter(
      (a) =>
        a.isRequired &&
        existing.has(valueKey(a.definition.id, null))
    ).length +
    variants.reduce(
      (count, variant) =>
        count +
        variantAttrs.filter(
          (a) =>
            a.isRequired &&
            existing.has(valueKey(a.definition.id, variant.id))
        ).length,
      0
    );

  const requiredPercent =
    requiredTargets === 0
      ? 100
      : Math.round((filledRequiredTargets / requiredTargets) * 100);

  return (
    <form action={formAction} className="space-y-6">
      <input type="hidden" name="productId" value={product.id} />

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-lg border bg-white p-4">
          <p className="text-xs uppercase text-neutral-500">Required specs</p>
          <p className="mt-2 text-2xl font-semibold">{requiredPercent}%</p>
          <p className="mt-1 text-xs text-neutral-500">
            {filledRequiredTargets}/{requiredTargets} required targets có dữ liệu
          </p>
        </div>

        <div className="rounded-lg border bg-white p-4">
          <p className="text-xs uppercase text-neutral-500">Active variants</p>
          <p className="mt-2 text-2xl font-semibold">{variants.length}</p>
          <p className="mt-1 text-xs text-neutral-500">
            VARIANT attributes sẽ lặp theo từng biến thể.
          </p>
        </div>

        <div className="rounded-lg border bg-white p-4">
          <p className="text-xs uppercase text-neutral-500">Derived</p>
          <p className="mt-2 text-2xl font-semibold">{derivedAttrs.length}</p>
          <p className="mt-1 text-xs text-neutral-500">
            Không required; dùng để stress-test ontology trước Product #10.
          </p>
        </div>
      </div>

      {state.errors.length > 0 ? (
        <div className="rounded-md border border-red-300 bg-red-50 p-4">
          <p className="font-medium text-red-900">Không thể lưu:</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-red-800">
            {state.errors.map((error, index) => (
              <li key={`${error}-${index}`}>{error}</li>
            ))}
          </ul>
        </div>
      ) : null}

      <section className="rounded-lg border bg-white">
        <div className="border-b px-5 py-4">
          <h2 className="font-semibold">Product-level specifications</h2>
          <p className="text-sm text-neutral-500">
            Không được gắn Variant cho nhóm này.
          </p>
        </div>
        <div className="px-5">
          {productAttrs.map((attribute) => (
            <AttributeRow
              key={attribute.definition.id}
              attribute={attribute}
              variant={null}
              current={existing.get(valueKey(attribute.definition.id, null))}
            />
          ))}
        </div>
      </section>

      <section className="rounded-lg border bg-white">
        <div className="border-b px-5 py-4">
          <h2 className="font-semibold">Variant-level specifications</h2>
          <p className="text-sm text-neutral-500">
            Desktop width/depth/material... nhập theo từng active Variant.
          </p>
        </div>

        {variants.length === 0 ? (
          <div className="px-5 py-6 text-sm text-amber-700">
            Product chưa có active Variant. Hãy tạo Variant trước khi nhập các
            attribute scope=VARIANT.
          </div>
        ) : (
          variants.map((variant) => (
            <div key={variant.id} className="border-b last:border-b-0">
              <div className="bg-neutral-50 px-5 py-3">
                <p className="font-medium">{variantLabel(variant)}</p>
              </div>
              <div className="px-5">
                {variantAttrs.map((attribute) => (
                  <AttributeRow
                    key={`${attribute.definition.id}-${variant.id}`}
                    attribute={attribute}
                    variant={variant}
                    current={existing.get(
                      valueKey(attribute.definition.id, variant.id)
                    )}
                  />
                ))}
              </div>
            </div>
          ))
        )}
      </section>

      <section className="rounded-lg border border-amber-300 bg-amber-50/30">
        <div className="border-b border-amber-200 px-5 py-4">
          <h2 className="font-semibold">Derived / Questionable</h2>
          <p className="text-sm text-neutral-600">
            Không phải raw manufacturer spec. V1 cho phép lưu ở Product-level
            hoặc Variant-level để 10 sản phẩm thật quyết định mô hình cuối.
          </p>
        </div>

        <div className="px-5">
          <h3 className="pt-4 text-sm font-semibold">Product-level derived</h3>
          {derivedAttrs.map((attribute) => (
            <AttributeRow
              key={`derived-product-${attribute.definition.id}`}
              attribute={attribute}
              variant={null}
              current={existing.get(valueKey(attribute.definition.id, null))}
            />
          ))}
        </div>

        {variants.map((variant) => (
          <div key={`derived-${variant.id}`} className="border-t border-amber-200">
            <div className="px-5 pt-4">
              <h3 className="text-sm font-semibold">
                Variant override · {variantLabel(variant)}
              </h3>
            </div>
            <div className="px-5">
              {derivedAttrs.map((attribute) => (
                <AttributeRow
                  key={`derived-${attribute.definition.id}-${variant.id}`}
                  attribute={attribute}
                  variant={variant}
                  current={existing.get(
                    valueKey(attribute.definition.id, variant.id)
                  )}
                />
              ))}
            </div>
          </div>
        ))}
      </section>

      <div className="sticky bottom-4 flex justify-end">
        <SubmitButton />
      </div>
    </form>
  );
}

// R2-fix: tách riêng vì useFormStatus() chỉ đọc được trạng thái pending của
// <form> cha khi được gọi từ MỘT COMPONENT CON của form đó — gọi thẳng trong
// ProductSpecificationsForm (component chứa chính thẻ <form>) sẽ luôn trả về
// pending=false.
function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <button
      type="submit"
      disabled={pending}
      className="rounded-md bg-blue-700 px-5 py-3 font-medium text-white shadow disabled:opacity-50"
    >
      {pending ? "Đang lưu…" : "Lưu Specifications"}
    </button>
  );
}
