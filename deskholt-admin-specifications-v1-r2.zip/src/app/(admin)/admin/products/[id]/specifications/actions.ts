// src/app/(admin)/admin/products/[id]/specifications/actions.ts
"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { Confidence, Prisma, SourceType } from "@prisma/client";

import { prisma } from "@/lib/prisma";
import { validateProductAttributeInput } from "@/lib/products/productAttributeValidator";

export type SaveSpecificationsState = {
  ok: boolean;
  errors: string[];
};

const EMPTY_STATE: SaveSpecificationsState = { ok: false, errors: [] };

type ExpectedRow = {
  attributeDefinitionId: number;
  key: string;
  dataType: "DECIMAL" | "INTEGER" | "STRING" | "BOOLEAN" | "ENUM";
  scope: "PRODUCT" | "VARIANT" | "DERIVED";
  variantId: number | null;
};

function fieldName(
  attributeDefinitionId: number,
  variantId: number | null,
  field: "value" | "sourceUrl" | "sourceType" | "confidence"
) {
  const target = variantId ?? 0;
  return `attr.${attributeDefinitionId}.${target}.${field}`;
}

function parseValue(
  dataType: ExpectedRow["dataType"],
  raw: FormDataEntryValue | null
): {
  valueString: string | null;
  valueNumber: number | null;
  valueBoolean: boolean | null;
  isBlank: boolean;
  parseError?: string;
} {
  const text = typeof raw === "string" ? raw.trim() : "";

  if (text === "") {
    return {
      valueString: null,
      valueNumber: null,
      valueBoolean: null,
      isBlank: true,
    };
  }

  switch (dataType) {
    case "DECIMAL":
    case "INTEGER": {
      // CSV Import should do its own locale normalization before calling the
      // shared validator. Admin inputs use canonical plain numbers only.
      const valueNumber = Number(text);
      return {
        valueString: null,
        valueNumber,
        valueBoolean: null,
        isBlank: false,
      };
    }

    case "BOOLEAN":
      if (text !== "true" && text !== "false") {
        return {
          valueString: null,
          valueNumber: null,
          valueBoolean: null,
          isBlank: false,
          parseError: `BOOLEAN nhận giá trị không hợp lệ: "${text}".`,
        };
      }
      return {
        valueString: null,
        valueNumber: null,
        valueBoolean: text === "true",
        isBlank: false,
      };

    case "STRING":
    case "ENUM":
      return {
        valueString: text,
        valueNumber: null,
        valueBoolean: null,
        isBlank: false,
      };
  }
}

function parseOptionalEnum<T extends string>(
  value: FormDataEntryValue | null,
  allowed: readonly T[]
): T | null {
  if (typeof value !== "string" || value.trim() === "") return null;
  return allowed.includes(value as T) ? (value as T) : null;
}

/**
 * Save toàn bộ Specifications của một Product.
 *
 * IMPORTANT:
 * - Không dùng Prisma upsert() cho ProductAttribute vì uniqueness thật của V1
 *   nằm ở 2 PostgreSQL partial unique indexes, Prisma không expose chúng như
 *   composite unique selector.
 * - Vì vậy: findFirst -> update/create trong transaction.
 * - Shared validator vẫn là cổng validation chung cho Admin + CSV Import.
 */
export async function saveProductSpecifications(
  _previousState: SaveSpecificationsState = EMPTY_STATE,
  formData: FormData
): Promise<SaveSpecificationsState> {
  const productId = Number(formData.get("productId"));

  if (!Number.isInteger(productId) || productId <= 0) {
    return { ok: false, errors: ["productId không hợp lệ."] };
  }

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: {
      id: true,
      categoryId: true,
      variants: {
        where: { isActive: true },
        select: { id: true },
        orderBy: { id: "asc" },
      },
      category: {
        select: {
          categoryAttributes: {
            orderBy: { displayOrder: "asc" },
            select: {
              attributeDefinition: {
                select: {
                  id: true,
                  key: true,
                  dataType: true,
                  scope: true,
                },
              },
            },
          },
        },
      },
    },
  });

  if (!product) {
    return { ok: false, errors: [`productId=${productId} không tồn tại.`] };
  }

  // Build target rows từ DB, không tin row identifiers do client tự gửi.
  const rows: ExpectedRow[] = [];

  for (const categoryAttr of product.category.categoryAttributes) {
    const definition = categoryAttr.attributeDefinition;

    if (definition.scope === "PRODUCT") {
      rows.push({
        attributeDefinitionId: definition.id,
        key: definition.key,
        dataType: definition.dataType,
        scope: definition.scope,
        variantId: null,
      });
      continue;
    }

    if (definition.scope === "VARIANT") {
      for (const variant of product.variants) {
        rows.push({
          attributeDefinitionId: definition.id,
          key: definition.key,
          dataType: definition.dataType,
          scope: definition.scope,
          variantId: variant.id,
        });
      }
      continue;
    }

    // DERIVED: product-level + optional per-variant override rows.
    rows.push({
      attributeDefinitionId: definition.id,
      key: definition.key,
      dataType: definition.dataType,
      scope: definition.scope,
      variantId: null,
    });

    for (const variant of product.variants) {
      rows.push({
        attributeDefinitionId: definition.id,
        key: definition.key,
        dataType: definition.dataType,
        scope: definition.scope,
        variantId: variant.id,
      });
    }
  }

  const existing = await prisma.productAttribute.findMany({
    where: { productId },
    select: {
      id: true,
      attributeDefinitionId: true,
      variantId: true,
    },
  });

  const existingByTarget = new Map(
    existing.map((row) => [
      `${row.attributeDefinitionId}:${row.variantId ?? 0}`,
      row,
    ])
  );

  const errors: string[] = [];
  const operations: Array<
    | {
        kind: "delete";
        id: number;
      }
    | {
        kind: "write";
        existingId: number | null;
        data: Prisma.ProductAttributeUncheckedCreateInput;
      }
  > = [];

  for (const row of rows) {
    const valueRaw = formData.get(
      fieldName(row.attributeDefinitionId, row.variantId, "value")
    );
    const parsed = parseValue(row.dataType, valueRaw);

    if (parsed.parseError) {
      errors.push(`[${row.key}] ${parsed.parseError}`);
      continue;
    }

    const sourceUrlRaw = formData.get(
      fieldName(row.attributeDefinitionId, row.variantId, "sourceUrl")
    );
    const sourceUrl =
      typeof sourceUrlRaw === "string" && sourceUrlRaw.trim() !== ""
        ? sourceUrlRaw.trim()
        : null;

    const sourceType = parseOptionalEnum(
      formData.get(
        fieldName(row.attributeDefinitionId, row.variantId, "sourceType")
      ),
      Object.values(SourceType)
    );

    const confidence =
      parseOptionalEnum(
        formData.get(
          fieldName(row.attributeDefinitionId, row.variantId, "confidence")
        ),
        Object.values(Confidence)
      ) ?? Confidence.UNVERIFIED;

    const targetKey = `${row.attributeDefinitionId}:${row.variantId ?? 0}`;
    const current = existingByTarget.get(targetKey);

    // Blank value + no metadata = user cleared row -> delete existing record.
    if (parsed.isBlank && !sourceUrl && !sourceType) {
      if (current) operations.push({ kind: "delete", id: current.id });
      continue;
    }

    // Metadata without a value is not useful in V1.
    if (parsed.isBlank) {
      errors.push(
        `[${row.key}] Có Source/Confidence nhưng chưa có value; hãy nhập value hoặc xóa metadata.`
      );
      continue;
    }

    const validation = await validateProductAttributeInput(prisma, {
      productId,
      variantId: row.variantId,
      attributeDefinitionId: row.attributeDefinitionId,
      valueString: parsed.valueString,
      valueNumber: parsed.valueNumber,
      valueBoolean: parsed.valueBoolean,
    });

    if (!validation.valid) {
      errors.push(...validation.errors);
      continue;
    }

    const data: Prisma.ProductAttributeUncheckedCreateInput = {
      productId,
      variantId: row.variantId,
      attributeDefinitionId: row.attributeDefinitionId,
      valueString: parsed.valueString,
      valueNumber: parsed.valueNumber,
      valueBoolean: parsed.valueBoolean,
      sourceUrl,
      sourceType,
      confidence,
      verifiedAt:
        confidence === Confidence.VERIFIED ? new Date() : null,
    };

    operations.push({
      kind: "write",
      existingId: current?.id ?? null,
      data,
    });
  }

  if (errors.length > 0) {
    return { ok: false, errors };
  }

  try {
    await prisma.$transaction(async (tx) => {
      for (const operation of operations) {
        if (operation.kind === "delete") {
          await tx.productAttribute.delete({
            where: { id: operation.id },
          });
          continue;
        }

        if (operation.existingId) {
          await tx.productAttribute.update({
            where: { id: operation.existingId },
            data: {
              valueString: operation.data.valueString,
              valueNumber: operation.data.valueNumber,
              valueBoolean: operation.data.valueBoolean,
              sourceUrl: operation.data.sourceUrl,
              sourceType: operation.data.sourceType,
              confidence: operation.data.confidence,
              verifiedAt: operation.data.verifiedAt,
            },
          });
        } else {
          await tx.productAttribute.create({ data: operation.data });
        }
      }
    });
  } catch (error) {
    // P2002 vẫn có thể xảy ra nếu có race condition / duplicate data cũ.
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    ) {
      return {
        ok: false,
        errors: [
          "Database từ chối một attribute bị trùng. Kiểm tra partial unique indexes và dữ liệu hiện tại.",
        ],
      };
    }
    throw error;
  }

  revalidatePath(`/admin/products/${productId}/specifications`);
  revalidatePath(`/admin/products/${productId}/edit`);

  redirect(`/admin/products/${productId}/specifications?saved=1`);
}
