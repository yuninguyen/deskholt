// src/app/(admin)/admin/products/[id]/specifications/page.tsx
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { ProductSpecificationsForm } from "@/components/admin/products/ProductSpecificationsForm";

type PageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ saved?: string }>;
};

export default async function ProductSpecificationsPage({
  params,
  searchParams,
}: PageProps) {
  const { id } = await params;
  const { saved } = await searchParams;
  const productId = Number(id);

  if (!Number.isInteger(productId) || productId <= 0) notFound();

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: {
      id: true,
      name: true,
      slug: true,
      category: {
        select: {
          id: true,
          name: true,
          slug: true,
          categoryAttributes: {
            orderBy: { displayOrder: "asc" },
            select: {
              isRequired: true,
              displayOrder: true,
              attributeDefinition: {
                select: {
                  id: true,
                  key: true,
                  label: true,
                  scope: true,
                  dataType: true,
                  unit: true,
                  allowedValues: true,
                },
              },
            },
          },
        },
      },
      variants: {
        where: { isActive: true },
        orderBy: { id: "asc" },
        select: {
          id: true,
          sku: true,
          size: true,
          color: true,
          material: true,
          width: true,
          depth: true,
        },
      },
      productAttributes: {
        select: {
          id: true,
          attributeDefinitionId: true,
          variantId: true,
          valueString: true,
          valueNumber: true,
          valueBoolean: true,
          sourceUrl: true,
          sourceType: true,
          confidence: true,
          verifiedAt: true,
        },
      },
    },
  });

  if (!product) notFound();

  const attributes = product.category.categoryAttributes.map((item) => ({
    isRequired: item.isRequired,
    displayOrder: item.displayOrder,
    definition: {
      ...item.attributeDefinition,
      allowedValues: Array.isArray(item.attributeDefinition.allowedValues)
        ? (item.attributeDefinition.allowedValues as string[])
        : [],
    },
  }));

  const values = product.productAttributes.map((value) => ({
    ...value,
    valueNumber: value.valueNumber?.toString() ?? null,
    verifiedAt: value.verifiedAt?.toISOString() ?? null,
  }));

  const variants = product.variants.map((variant) => ({
    ...variant,
    width: variant.width?.toString() ?? null,
    depth: variant.depth?.toString() ?? null,
  }));

  return (
    <div className="mx-auto max-w-[1500px] space-y-6 p-6">
      <header className="space-y-1">
        <p className="font-mono text-xs uppercase tracking-wide text-neutral-500">
          {product.category.name} · Product #{product.id}
        </p>
        <h1 className="text-2xl font-semibold">{product.name}</h1>
        <p className="text-sm text-neutral-500">
          V1 Specifications — nhập dữ liệu thật trước, tối ưu ontology sau Product #10.
        </p>
      </header>

      {saved === "1" ? (
        <div className="rounded-md border border-green-300 bg-green-50 px-4 py-3 text-sm text-green-800">
          Đã lưu specifications.
        </div>
      ) : null}

      <ProductSpecificationsForm
        product={{
          id: product.id,
          name: product.name,
          categoryName: product.category.name,
        }}
        attributes={attributes}
        variants={variants}
        values={values}
      />
    </div>
  );
}
